1.0.6
  - Fix the extension not working for https://web.whatsapp.com

1.0.5
  - Fix manifest description being too long from v1.0.4

1.0.4
  - CSP headers are enabled by default when you install this extension. You must
    click the extention's button to disable CSP.

1.0.3
  - Fixes bad extension packaging of 1.0.2. Do not use 1.0.2.

1.0.2
  - Make the extension work for iframes.

1.0.1
  - Initial version.
